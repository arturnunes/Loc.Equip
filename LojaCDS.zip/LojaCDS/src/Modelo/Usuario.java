package Modelo;

import DAO.ExecuteSQL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;


public class Usuario {
 private String online;
  private int codigo;
  private String nome;
  private String email;
   private int cpf;
   private int telefone;
  private String login;
   private String senha;
  private String senha2;

    public String getOnline() {
        return online;
    }

    public void setOnline(String online) {
        this.online = online;
    } 
  
    public String getSenha2() {
        return senha2;
    }

    public void setSenha2(String senha2) {
        this.senha2 = senha2;
    }

    public int getCpf() {
        return cpf;
    }

    public void setCpf(int cpf) {
        this.cpf = cpf;
    }

    public int getTelefone() {
        return telefone;
    }

    public void setTelefone(int telefone) {
        this.telefone = telefone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
  
    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }
    
}
