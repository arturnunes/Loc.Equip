<?php
/**
 * As configurações básicas do WordPress
 *
 * O script de criação wp-config.php usa esse arquivo durante a instalação.
 * Você não precisa usar o site, você pode copiar este arquivo
 * para "wp-config.php" e preencher os valores.
 *
 * Este arquivo contém as seguintes configurações:
 *
 * * Configurações do MySQL
 * * Chaves secretas
 * * Prefixo do banco de dados
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/pt-br:Editando_wp-config.php
 *
 * @package WordPress
 */

// ** Configurações do MySQL - Você pode pegar estas informações com o serviço de hospedagem ** //
/** O nome do banco de dados do WordPress */
define('DB_NAME', 'wordpress');

/** Usuário do banco de dados MySQL */
define('DB_USER', 'root');

/** Senha do banco de dados MySQL */
define('DB_PASSWORD', '');

/** Nome do host do MySQL */
define('DB_HOST', 'localhost');

/** Charset do banco de dados a ser usado na criação das tabelas. */
define('DB_CHARSET', 'utf8mb4');

/** O tipo de Collate do banco de dados. Não altere isso se tiver dúvidas. */
define('DB_COLLATE', '');

/**#@+
 * Chaves únicas de autenticação e salts.
 *
 * Altere cada chave para um frase única!
 * Você pode gerá-las
 * usando o {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org
 * secret-key service}
 * Você pode alterá-las a qualquer momento para invalidar quaisquer
 * cookies existentes. Isto irá forçar todos os
 * usuários a fazerem login novamente.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '@Vk?V*M?lGzn=Ph6hdNN`X;fCskLG(G5{j(j[~R0ZX~rHScE@PA~&EVBRe==9DBZ');
define('SECURE_AUTH_KEY',  '*p[!A/m^?~7xs6RfA^@d)qH4-{9(G=D*c,N^8W.?m_iy*V=gP-[0JeX[ pVHGpgZ');
define('LOGGED_IN_KEY',    'm#w_}*pno%oyl+it20mS1</KU =B?R80mdjeWFbD$-M9`D2gcG_Ry|7ZGNQQ((Z?');
define('NONCE_KEY',        '~(2;br?,hMAd~AU,=4VV#@c db!FEZiubW&Qk8/tb7sM>ifRy^?^e~Ozm58-hK64');
define('AUTH_SALT',        '*MKCs/.eF|O5NeCH^ .*G5`~:POwf51dT<a=~mnG^c|T/! Vm+}`u8)j4IoA.FJ+');
define('SECURE_AUTH_SALT', 'NS5]2=fXoJY1~&Y((j>ECPeENMQ>vdTN4%7@2cGOBlC&9W?J$Pq`(4.C+YzF30nD');
define('LOGGED_IN_SALT',   'Nz0Hq#oj3`PmDwu!#2`D*O+,.C3Z>]f.RXnjY@GA3SLs_,8_xM5Xp_~eHK 5qi0Z');
define('NONCE_SALT',       '^s<}$?w3^kQHVm#l#SDy2ETmm-@`&<;#HOR4pa]NAp9]#:Y,/aq30/%6q&TR6)1c');

/**#@-*/

/**
 * Prefixo da tabela do banco de dados do WordPress.
 *
 * Você pode ter várias instalações em um único banco de dados se você der
 * um prefixo único para cada um. Somente números, letras e sublinhados!
 */
$table_prefix  = 'wp_';

/**
 * Para desenvolvedores: Modo de debug do WordPress.
 *
 * Altere isto para true para ativar a exibição de avisos
 * durante o desenvolvimento. É altamente recomendável que os
 * desenvolvedores de plugins e temas usem o WP_DEBUG
 * em seus ambientes de desenvolvimento.
 *
 * Para informações sobre outras constantes que podem ser utilizadas
 * para depuração, visite o Codex.
 *
 * @link https://codex.wordpress.org/pt-br:Depura%C3%A7%C3%A3o_no_WordPress
 */
define('WP_DEBUG', false);

/* Isto é tudo, pode parar de editar! :) */

/** Caminho absoluto para o diretório WordPress. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Configura as variáveis e arquivos do WordPress. */
require_once(ABSPATH . 'wp-settings.php');
