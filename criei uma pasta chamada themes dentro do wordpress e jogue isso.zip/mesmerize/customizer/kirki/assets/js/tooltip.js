jQuery( document ).ready( function( $ ) {
	$( 'a.tooltip' ).tooltip();
});
