<?php

return array (
  'preset-1' => 
  array (
    'index' => 0,
    'id' => 'header_preset_0',
    'thumb' => '//onepageexpress.com/default-assets/previews/headers/preset-1.png',
    'preview' => '//onepageexpress.com/default-assets/previews/headers/preset-1.png',
    'description' => 'full height image with color overlay',
    'settings' => 
    array (
      'one_page_express_headernav_header_1' => '',
      'one_page_express_header_nav_border' => '0',
      'one_page_express_header_nav_boxed' => '0',
      'one_page_express_header_nav_sticked' => '1',
      'one_page_express_header_nav_transparent' => '1',
      'one_page_express_header_header_1' => '',
      'one_page_express_full_height' => '1',
      'one_page_express_header_gradient' => 'plum_plate',
      'one_page_express_header_slideshow' => 
      array (
        0 => 
        array (
          'url' => '[tag_theme_uri]/assets/images/home_page_header.jpg',
        ),
        1 => 
        array (
          'url' => '[tag_theme_uri]/assets/images/jeremy-bishop-14593.jpg',
        ),
      ),
      'one_page_express_header_slideshow_duration' => 5000,
      'one_page_express_header_slideshow_speed' => 1000,
      'one_page_express_header_parallax' => '1',
      'one_page_express_header_overlay_header' => '',
      'one_page_express_header_show_overlay' => '1',
      'one_page_express_header_overlay_color' => '#D91584',
      'one_page_express_header_overlay_opacity' => '0.84',
      'one_page_express_header_separator_header' => '',
      'one_page_express_header_show_separator' => '0',
      'one_page_express_header_separator' => 'triangle-asymmetrical-negative',
      'one_page_express_header_separator_height' => '90',
      'one_page_express_inner_headernav_header_1' => '',
      'one_page_express_inner_header_nav_border' => '0',
      'one_page_express_inner_header_nav_boxed' => '0',
      'one_page_express_inner_header_nav_sticked' => '1',
      'one_page_express_inner_header_nav_transparent' => '1',
      'one_page_express_inner_header_header_1' => '',
      'one_page_express_inner_header_gradient' => 'plum_plate',
      'one_page_express_inner_header_slideshow' => 
      array (
        0 => 
        array (
          'url' => 'http://10.44.205.110/wp-content/themes/one-page-express/assets/images/home_page_header.jpg',
        ),
        1 => 
        array (
          'url' => 'http://10.44.205.110/wp-content/themes/one-page-express/assets/images/jeremy-bishop-14593.jpg',
        ),
      ),
      'one_page_express_inner_header_slideshow_duration' => 5000,
      'one_page_express_inner_header_slideshow_speed' => 1000,
      'one_page_express_inner_header_parallax' => '1',
      'one_page_express_inner_header_overlay_header' => '',
      'one_page_express_inner_header_show_overlay' => '1',
      'one_page_express_inner_header_overlay_color' => '#000',
      'one_page_express_inner_header_overlay_opacity' => 0.4,
      'one_page_express_inner_header_separator_header' => '',
      'one_page_express_inner_header_show_separator' => '1',
      'one_page_express_inner_header_separator' => 'triangle-asymmetrical-negative',
      'one_page_express_inner_header_separator_height' => 90,
      'one_page_express_inner_header_text_align' => 'center',
      'one_page_express_inner_header_show_subtitle' => '1',
      'one_page_express_inner_header_spacing' => 
      array (
        'top' => '8%',
        'bottom' => '8%',
      ),
      'one_page_express_header_content_separator' => '',
      'one_page_express_blog_header_overlap' => '1',
      'one_page_express_blog_header_margin' => '200px',
      'one_page_express_header_content_partial' => 'content-on-left',
      'one_page_express_header_text_align' => 'left',
      'one_page_express_header_spacing' => 
      array (
        'top' => '30%',
        'bottom' => '8%',
      ),
      'one_page_express_header_column_width' => 50,
      'one_page_express_header_content_width' => '65',
      'one_page_express_header_content_image' => '[tag_theme_uri]/screenshot.jpg',
      'one_page_express_header_content_title_separator' => '',
      'one_page_express_header_show_title' => '1',
      'one_page_express_header_content_subtitle_separator' => '',
      'one_page_express_header_show_subtitle' => '1',
      'one_page_express_header_content_primary_button_separator' => '',
      'one_page_express_header_show_btn_1' => '0',
      'one_page_express_header_btn_1_label' => '',
      'one_page_express_header_btn_1_url' => '#',
      'one_page_express_header_content_secondary_button_separator' => '',
      'one_page_express_header_show_btn_2' => '0',
      'one_page_express_header_btn_2_label' => '',
      'one_page_express_header_btn_2_url' => '#',
      'ope_header_content_layout' => 'content-on-right',
      'one_page_express_header_video_popup_image' => '[tag_theme_uri]/assets/images/Mock-up.jpg',
      'header_text_logo_title_typography_sep' => '',
      'header_text_logo_title_typography' => 
      array (
        'font-family' => 'inherit',
        'font-size' => '2.6em',
        'font-weight' => '600',
        'line-height' => '100%',
        'letter-spacing' => '0px',
        'subsets' => 
        array (
        ),
        'text-transform' => 'none',
        'color' => '#FFFFFF',
      ),
      'header_text_logo_sticky_typography' => '#000000',
      'header_nav_title_typography_sep' => '',
      'header_nav_title_typography' => 
      array (
        'font-family' => 'inherit',
        'font-size' => '1em',
        'font-weight' => '400',
        'line-height' => '115%',
        'letter-spacing' => '3px',
        'subsets' => 
        array (
        ),
        'text-transform' => 'uppercase',
        'color' => '#EDEDED',
      ),
      'header_nav_sitcky_title_typography' => '#000000',
      'header_content_inner_nav_sep' => '',
      'inner_header_nav_logo_color' => '#ffffff',
      'inner_header_nav_menu_color' => '#FFFFFF',
      'ope_header_nav_bar_color' => '#FFFFFF',
      'ope_inner_header_nav_bar_color' => '#FFFFFF',
      'header_content_title_typography' => 
      array (
        'font-family' => 'Source Sans Pro',
        'font-size' => '3.3em',
        'font-weight' => '600',
        'line-height' => '115%',
        'letter-spacing' => 'normal',
        'subsets' => 
        array (
        ),
        'color' => '#ffffff',
        'text-transform' => 'uppercase',
      ),
      'header_content_title_spacing' => 
      array (
        'top' => '0',
        'bottom' => '25px',
      ),
      'header_content_subtitle_typography' => 
      array (
        'font-family' => 'Source Sans Pro',
        'font-size' => '1.4em',
        'font-weight' => '300',
        'line-height' => '130%',
        'letter-spacing' => 'normal',
        'subsets' => 
        array (
        ),
        'color' => '#ffffff',
        'text-transform' => 'none',
      ),
      'header_content_subtitle_spacing' => 
      array (
        'top' => '0',
        'bottom' => '0',
      ),
      'header_content_inner_typography_sep' => '',
      'header_content_inner_title_typography' => 
      array (
        'font-family' => 'Source Sans Pro',
        'font-size' => '3.3em',
        'font-weight' => '600',
        'line-height' => '115%',
        'letter-spacing' => 'normal',
        'subsets' => 
        array (
        ),
        'color' => '#ffffff',
        'text-transform' => 'uppercase',
      ),
      'ope_header_content_media' => 'image',
      'ope_pro_header_content_video' => 'https://www.youtube.com/watch?v=3iXYciBTQ0c',
      'header_content_media_spacing' => 
      array (
        'top' => '0',
        'bottom' => '0',
      ),
      'one_page_express_header_show_bottom_arrow_separator' => '',
      'one_page_express_header_show_bottom_arrow' => '0',
      'one_page_express_header_bottom_arrow' => 'fa-chevron-down',
      'one_page_express_header_size_bottom_arrow' => '20',
      'one_page_express_header_offset_bottom_arrow' => '20',
      'one_page_express_header_color_bottom_arrow' => '#000000',
      'one_page_express_header_background_bottom_arrow' => '#ffffff',
      'one_page_express_header_text_morph_separator' => '',
      'one_page_express_header_show_text_morph_animation' => '1',
      'one_page_express_header_text_morph_speed' => 200,
      'one_page_express_header_text_morph_alternatives' => '',
      'one_page_express_header_bounce_bottom_arrow' => '1',
      'ope_pro_header_buttons_type' => 'normal',
      'one_page_express_header_content_subtitle_separator2' => '',
      'one_page_express_header_show_subtitle2' => '0',
      'header_content_subtitle_typography2' => 
      array (
        'font-family' => 'Source Sans Pro',
        'font-size' => '1.4em',
        'variant' => '300',
        'line-height' => '130%',
        'letter-spacing' => 'normal',
        'subsets' => 
        array (
        ),
        'color' => '#ffffff',
        'text-transform' => 'none',
      ),
      'header_content_subtitle_spacing2' => 
      array (
        'top' => '0',
        'bottom' => '0',
      ),
      'header_content_text_vertical_align' => 'v-align-top',
      'header_content_vertical_align' => 'v-align-top',
      'header_content_video_img_shadow' => '1',
      'header_content_inner_subtitle_typography' => 
      array (
        'font-family' => 'Source Sans Pro',
        'font-size' => '1.4em',
        'font-weight' => '300',
        'line-height' => '130%',
        'letter-spacing' => 'normal',
        'subsets' => 
        array (
        ),
        'color' => '#ffffff',
        'text-transform' => 'none',
      ),
      'one_page_express_header_content_image_rounded' => '0',
      'one_page_express_header_video_popup_image_disabled' => false,
      'header_nav_menu_color' => '#FFFFFF',
      'header_nav_sticky_title_typography' => '#000000',
      'header_text_logo_color' => '#ffffff',
      'one_page_express_header_btn_1_class' => 'button hp-header-primary-button blue big',
      'one_page_express_header_btn_2_class' => 'button hp-header-secondary-button green big',
      'content_media_vertical_align' => 'center',
      'one_page_express_header_color_video_popup_button' => '#FFFFFF',
      'one_page_express_header_color_video_popup_button_hover' => '#03a9f4',
      'one_page_express_header_image' => '[tag_theme_uri]/assets/images/photo-1455894127589-22f75500213a.jpeg',
      'one_page_express_front_page_header_overlap' => '0',
      'one_page_express_header_background_type' => 'image',
    ),
  ),
  'preset-2' => 
  array (
    'index' => 1,
    'id' => 'header_preset_1',
    'thumb' => '//onepageexpress.com/default-assets/previews/headers/preset-2.png',
    'preview' => '//onepageexpress.com/default-assets/previews/headers/preset-2.png',
    'description' => 'video background with bottom separator',
    'settings' => 
    array (
      'one_page_express_headernav_header_1' => '',
      'one_page_express_header_nav_border' => '0',
      'one_page_express_header_nav_boxed' => '0',
      'one_page_express_header_nav_sticked' => '1',
      'one_page_express_header_nav_transparent' => '1',
      'one_page_express_header_header_1' => '',
      'one_page_express_full_height' => '0',
      'one_page_express_header_gradient' => 'plum_plate',
      'one_page_express_header_slideshow' => 
      array (
        0 => 
        array (
          'url' => '[tag_theme_uri]/assets/images/home_page_header.jpg',
        ),
        1 => 
        array (
          'url' => '[tag_theme_uri]/assets/images/jeremy-bishop-14593.jpg',
        ),
      ),
      'one_page_express_header_slideshow_duration' => 5000,
      'one_page_express_header_slideshow_speed' => 1000,
      'one_page_express_header_parallax' => '1',
      'one_page_express_header_overlay_header' => '',
      'one_page_express_header_show_overlay' => '1',
      'one_page_express_header_overlay_color' => '#000',
      'one_page_express_header_overlay_opacity' => 0.4,
      'one_page_express_header_separator_header' => '',
      'one_page_express_header_show_separator' => '1',
      'one_page_express_header_separator' => 'triangle-asymmetrical-negative',
      'one_page_express_header_separator_height' => 90,
      'one_page_express_inner_headernav_header_1' => '',
      'one_page_express_inner_header_nav_border' => '0',
      'one_page_express_inner_header_nav_boxed' => '0',
      'one_page_express_inner_header_nav_sticked' => '1',
      'one_page_express_inner_header_nav_transparent' => '1',
      'one_page_express_inner_header_header_1' => '',
      'one_page_express_inner_header_gradient' => 'plum_plate',
      'one_page_express_inner_header_slideshow' => 
      array (
        0 => 
        array (
          'url' => 'http://10.44.205.110/wp-content/themes/one-page-express/assets/images/home_page_header.jpg',
        ),
        1 => 
        array (
          'url' => 'http://10.44.205.110/wp-content/themes/one-page-express/assets/images/jeremy-bishop-14593.jpg',
        ),
      ),
      'one_page_express_inner_header_slideshow_duration' => 5000,
      'one_page_express_inner_header_slideshow_speed' => 1000,
      'one_page_express_inner_header_parallax' => '1',
      'one_page_express_inner_header_overlay_header' => '',
      'one_page_express_inner_header_show_overlay' => '1',
      'one_page_express_inner_header_overlay_color' => '#000',
      'one_page_express_inner_header_overlay_opacity' => 0.4,
      'one_page_express_inner_header_separator_header' => '',
      'one_page_express_inner_header_show_separator' => '1',
      'one_page_express_inner_header_separator' => 'triangle-asymmetrical-negative',
      'one_page_express_inner_header_separator_height' => 90,
      'one_page_express_inner_header_text_align' => 'center',
      'one_page_express_inner_header_show_subtitle' => '1',
      'one_page_express_inner_header_spacing' => 
      array (
        'top' => '8%',
        'bottom' => '8%',
      ),
      'one_page_express_header_content_separator' => '',
      'one_page_express_blog_header_overlap' => '1',
      'one_page_express_blog_header_margin' => '200px',
      'one_page_express_header_content_partial' => 'content-on-right',
      'one_page_express_header_text_align' => 'right',
      'one_page_express_header_spacing' => 
      array (
        'top' => '8%',
        'bottom' => '10%',
      ),
      'one_page_express_header_column_width' => 50,
      'one_page_express_header_content_width' => '62',
      'one_page_express_header_content_image' => '[tag_theme_uri]/screenshot.jpg',
      'one_page_express_header_content_title_separator' => '',
      'one_page_express_header_show_title' => '1',
      'one_page_express_header_content_subtitle_separator' => '',
      'one_page_express_header_show_subtitle' => '1',
      'one_page_express_header_content_primary_button_separator' => '',
      'one_page_express_header_show_btn_1' => '1',
      'one_page_express_header_btn_1_label' => '',
      'one_page_express_header_btn_1_url' => '#',
      'one_page_express_header_content_secondary_button_separator' => '',
      'one_page_express_header_show_btn_2' => '1',
      'one_page_express_header_btn_2_label' => '',
      'one_page_express_header_btn_2_url' => '#',
      'ope_header_content_layout' => 'content-on-right',
      'one_page_express_header_video_popup_image' => '[tag_theme_uri]/assets/images/Mock-up.jpg',
      'header_text_logo_title_typography_sep' => '',
      'header_text_logo_title_typography' => 
      array (
        'font-family' => 'inherit',
        'font-size' => '2.6em',
        'font-weight' => '600',
        'line-height' => '100%',
        'letter-spacing' => '0px',
        'subsets' => 
        array (
        ),
        'text-transform' => 'none',
        'color' => '#FFFFFF',
      ),
      'header_text_logo_sticky_typography' => '#000000',
      'header_nav_title_typography_sep' => '',
      'header_nav_title_typography' => 
      array (
        'font-family' => 'inherit',
        'font-size' => '1em',
        'font-weight' => '400',
        'line-height' => '115%',
        'letter-spacing' => '3px',
        'subsets' => 
        array (
        ),
        'text-transform' => 'uppercase',
        'color' => '#EDEDED',
      ),
      'header_nav_sitcky_title_typography' => '#000000',
      'header_content_inner_nav_sep' => '',
      'inner_header_nav_logo_color' => '#ffffff',
      'inner_header_nav_menu_color' => '#FFFFFF',
      'ope_header_nav_bar_color' => '#FFFFFF',
      'ope_inner_header_nav_bar_color' => '#FFFFFF',
      'header_content_title_typography' => 
      array (
        'font-family' => 'Source Sans Pro',
        'font-size' => '3.3em',
        'font-weight' => '600',
        'line-height' => '115%',
        'letter-spacing' => 'normal',
        'subsets' => 
        array (
        ),
        'color' => '#ffffff',
        'text-transform' => 'uppercase',
      ),
      'header_content_title_spacing' => 
      array (
        'top' => '0',
        'bottom' => '25px',
      ),
      'header_content_subtitle_typography' => 
      array (
        'font-family' => 'Source Sans Pro',
        'font-size' => '1.4em',
        'font-weight' => '300',
        'line-height' => '130%',
        'letter-spacing' => 'normal',
        'subsets' => 
        array (
        ),
        'color' => '#ffffff',
        'text-transform' => 'none',
      ),
      'header_content_subtitle_spacing' => 
      array (
        'top' => '0',
        'bottom' => '0',
      ),
      'header_content_inner_typography_sep' => '',
      'header_content_inner_title_typography' => 
      array (
        'font-family' => 'Source Sans Pro',
        'font-size' => '3.3em',
        'font-weight' => '600',
        'line-height' => '115%',
        'letter-spacing' => 'normal',
        'subsets' => 
        array (
        ),
        'color' => '#ffffff',
        'text-transform' => 'uppercase',
      ),
      'ope_header_content_media' => 'image',
      'ope_pro_header_content_video' => 'https://www.youtube.com/watch?v=3iXYciBTQ0c',
      'header_content_media_spacing' => 
      array (
        'top' => '0',
        'bottom' => '0',
      ),
      'one_page_express_header_show_bottom_arrow_separator' => '',
      'one_page_express_header_show_bottom_arrow' => '0',
      'one_page_express_header_bottom_arrow' => 'fa-chevron-down',
      'one_page_express_header_size_bottom_arrow' => '20',
      'one_page_express_header_offset_bottom_arrow' => '20',
      'one_page_express_header_color_bottom_arrow' => '#000000',
      'one_page_express_header_background_bottom_arrow' => '#ffffff',
      'one_page_express_header_text_morph_separator' => '',
      'one_page_express_header_show_text_morph_animation' => '1',
      'one_page_express_header_text_morph_speed' => 200,
      'one_page_express_header_text_morph_alternatives' => '',
      'one_page_express_header_bounce_bottom_arrow' => '1',
      'ope_pro_header_buttons_type' => 'normal',
      'one_page_express_header_content_subtitle_separator2' => '',
      'one_page_express_header_show_subtitle2' => '0',
      'header_content_subtitle_typography2' => 
      array (
        'font-family' => 'Source Sans Pro',
        'font-size' => '1.4em',
        'variant' => '300',
        'line-height' => '130%',
        'letter-spacing' => 'normal',
        'subsets' => 
        array (
        ),
        'color' => '#ffffff',
        'text-transform' => 'none',
      ),
      'header_content_subtitle_spacing2' => 
      array (
        'top' => '0',
        'bottom' => '0',
      ),
      'header_content_text_vertical_align' => 'v-align-top',
      'header_content_vertical_align' => 'v-align-top',
      'header_content_video_img_shadow' => '1',
      'header_content_inner_subtitle_typography' => 
      array (
        'font-family' => 'Source Sans Pro',
        'font-size' => '1.4em',
        'font-weight' => '300',
        'line-height' => '130%',
        'letter-spacing' => 'normal',
        'subsets' => 
        array (
        ),
        'color' => '#ffffff',
        'text-transform' => 'none',
      ),
      'one_page_express_header_content_image_rounded' => '0',
      'one_page_express_header_video_popup_image_disabled' => false,
      'header_nav_menu_color' => '#FFFFFF',
      'header_nav_sticky_title_typography' => '#000000',
      'header_text_logo_color' => '#ffffff',
      'one_page_express_header_btn_1_class' => 'button hp-header-primary-button blue big',
      'one_page_express_header_btn_2_class' => 'button hp-header-secondary-button green big',
      'content_media_vertical_align' => 'center',
      'one_page_express_header_color_video_popup_button' => '#FFFFFF',
      'one_page_express_header_color_video_popup_button_hover' => '#03a9f4',
      'one_page_express_header_background_type' => 'video',
      'one_page_express_front_page_header_margin' => '200px',
      'one_page_express_header_image' => '[tag_theme_uri]/assets/images/home_page_header.jpg',
    ),
  ),
  'preset-3' => 
  array (
    'index' => 2,
    'id' => 'header_preset_2',
    'thumb' => '//onepageexpress.com/default-assets/previews/headers/preset-3.png',
    'preview' => '//onepageexpress.com/default-assets/previews/headers/preset-3.png',
    'description' => 'gradient background with image and text',
    'settings' => 
    array (
      'one_page_express_headernav_header_1' => '',
      'one_page_express_header_nav_border' => '0',
      'one_page_express_header_nav_boxed' => '0',
      'one_page_express_header_nav_sticked' => '1',
      'one_page_express_header_nav_transparent' => '1',
      'one_page_express_header_header_1' => '',
      'one_page_express_full_height' => '0',
      'one_page_express_header_gradient' => 'plum_plate',
      'one_page_express_header_slideshow' => 
      array (
        0 => 
        array (
          'url' => '[tag_theme_uri]/assets/images/home_page_header.jpg',
        ),
        1 => 
        array (
          'url' => '[tag_theme_uri]/assets/images/jeremy-bishop-14593.jpg',
        ),
      ),
      'one_page_express_header_slideshow_duration' => 5000,
      'one_page_express_header_slideshow_speed' => 1000,
      'one_page_express_header_parallax' => '1',
      'one_page_express_header_overlay_header' => '',
      'one_page_express_header_show_overlay' => '1',
      'one_page_express_header_overlay_color' => '#000',
      'one_page_express_header_overlay_opacity' => '0.4',
      'one_page_express_header_separator_header' => '',
      'one_page_express_header_show_separator' => '1',
      'one_page_express_header_separator' => 'pyramids-negative',
      'one_page_express_header_separator_height' => 90,
      'one_page_express_inner_headernav_header_1' => '',
      'one_page_express_inner_header_nav_border' => '0',
      'one_page_express_inner_header_nav_boxed' => '0',
      'one_page_express_inner_header_nav_sticked' => '1',
      'one_page_express_inner_header_nav_transparent' => '1',
      'one_page_express_inner_header_header_1' => '',
      'one_page_express_inner_header_gradient' => 'plum_plate',
      'one_page_express_inner_header_slideshow' => 
      array (
        0 => 
        array (
          'url' => 'http://10.44.205.110/wp-content/themes/one-page-express/assets/images/home_page_header.jpg',
        ),
        1 => 
        array (
          'url' => 'http://10.44.205.110/wp-content/themes/one-page-express/assets/images/jeremy-bishop-14593.jpg',
        ),
      ),
      'one_page_express_inner_header_slideshow_duration' => 5000,
      'one_page_express_inner_header_slideshow_speed' => 1000,
      'one_page_express_inner_header_parallax' => '1',
      'one_page_express_inner_header_overlay_header' => '',
      'one_page_express_inner_header_show_overlay' => '1',
      'one_page_express_inner_header_overlay_color' => '#000',
      'one_page_express_inner_header_overlay_opacity' => 0.4,
      'one_page_express_inner_header_separator_header' => '',
      'one_page_express_inner_header_show_separator' => '1',
      'one_page_express_inner_header_separator' => 'triangle-asymmetrical-negative',
      'one_page_express_inner_header_separator_height' => 90,
      'one_page_express_inner_header_text_align' => 'center',
      'one_page_express_inner_header_show_subtitle' => '1',
      'one_page_express_inner_header_spacing' => 
      array (
        'top' => '8%',
        'bottom' => '8%',
      ),
      'one_page_express_header_content_separator' => '',
      'one_page_express_blog_header_overlap' => '1',
      'one_page_express_blog_header_margin' => '200px',
      'one_page_express_header_content_partial' => 'image-on-left',
      'one_page_express_header_text_align' => 'left',
      'one_page_express_header_spacing' => 
      array (
        'top' => '4%',
        'bottom' => '0%',
      ),
      'one_page_express_header_column_width' => '50',
      'one_page_express_header_content_width' => '95',
      'one_page_express_header_content_image' => '[tag_theme_uri]/screenshot.jpg',
      'one_page_express_header_content_title_separator' => '',
      'one_page_express_header_show_title' => '1',
      'one_page_express_header_content_subtitle_separator' => '',
      'one_page_express_header_show_subtitle' => '1',
      'one_page_express_header_content_primary_button_separator' => '',
      'one_page_express_header_show_btn_1' => '1',
      'one_page_express_header_btn_1_label' => '',
      'one_page_express_header_btn_1_url' => '#',
      'one_page_express_header_content_secondary_button_separator' => '',
      'one_page_express_header_show_btn_2' => '1',
      'one_page_express_header_btn_2_label' => '',
      'one_page_express_header_btn_2_url' => '#',
      'ope_header_content_layout' => 'content-on-right',
      'one_page_express_header_video_popup_image' => '[tag_theme_uri]/assets/images/Mock-up.jpg',
      'header_text_logo_title_typography_sep' => '',
      'header_text_logo_title_typography' => 
      array (
        'font-family' => 'inherit',
        'font-size' => '2.6em',
        'font-weight' => '600',
        'line-height' => '100%',
        'letter-spacing' => '0px',
        'subsets' => 
        array (
        ),
        'text-transform' => 'none',
        'color' => '#FFFFFF',
      ),
      'header_text_logo_sticky_typography' => '#000000',
      'header_nav_title_typography_sep' => '',
      'header_nav_title_typography' => 
      array (
        'font-family' => 'inherit',
        'font-size' => '1em',
        'font-weight' => '400',
        'line-height' => '115%',
        'letter-spacing' => '3px',
        'subsets' => 
        array (
        ),
        'text-transform' => 'uppercase',
        'color' => '#EDEDED',
      ),
      'header_nav_sitcky_title_typography' => '#000000',
      'header_content_inner_nav_sep' => '',
      'inner_header_nav_logo_color' => '#ffffff',
      'inner_header_nav_menu_color' => '#FFFFFF',
      'ope_header_nav_bar_color' => '#FFFFFF',
      'ope_inner_header_nav_bar_color' => '#FFFFFF',
      'header_content_title_typography' => 
      array (
        'font-family' => 'Source Sans Pro',
        'font-size' => '3.3em',
        'font-weight' => '600',
        'line-height' => '115%',
        'letter-spacing' => 'normal',
        'subsets' => 
        array (
        ),
        'color' => '#ffffff',
        'text-transform' => 'uppercase',
      ),
      'header_content_title_spacing' => 
      array (
        'top' => '0',
        'bottom' => '25px',
      ),
      'header_content_subtitle_typography' => 
      array (
        'font-family' => 'Source Sans Pro',
        'font-size' => '1.4em',
        'font-weight' => '300',
        'line-height' => '130%',
        'letter-spacing' => 'normal',
        'subsets' => 
        array (
        ),
        'color' => '#ffffff',
        'text-transform' => 'none',
      ),
      'header_content_subtitle_spacing' => 
      array (
        'top' => '0',
        'bottom' => '0',
      ),
      'header_content_inner_typography_sep' => '',
      'header_content_inner_title_typography' => 
      array (
        'font-family' => 'Source Sans Pro',
        'font-size' => '3.3em',
        'font-weight' => '600',
        'line-height' => '115%',
        'letter-spacing' => 'normal',
        'subsets' => 
        array (
        ),
        'color' => '#ffffff',
        'text-transform' => 'uppercase',
      ),
      'ope_header_content_media' => 'image',
      'ope_pro_header_content_video' => 'https://www.youtube.com/watch?v=3iXYciBTQ0c',
      'header_content_media_spacing' => 
      array (
        'top' => '0',
        'bottom' => '0',
      ),
      'one_page_express_header_show_bottom_arrow_separator' => '',
      'one_page_express_header_show_bottom_arrow' => '0',
      'one_page_express_header_bottom_arrow' => 'fa-chevron-down',
      'one_page_express_header_size_bottom_arrow' => '20',
      'one_page_express_header_offset_bottom_arrow' => '20',
      'one_page_express_header_color_bottom_arrow' => '#000000',
      'one_page_express_header_background_bottom_arrow' => '#ffffff',
      'one_page_express_header_text_morph_separator' => '',
      'one_page_express_header_show_text_morph_animation' => '1',
      'one_page_express_header_text_morph_speed' => 200,
      'one_page_express_header_text_morph_alternatives' => '',
      'one_page_express_header_bounce_bottom_arrow' => '1',
      'ope_pro_header_buttons_type' => 'normal',
      'one_page_express_header_content_subtitle_separator2' => '',
      'one_page_express_header_show_subtitle2' => '0',
      'header_content_subtitle_typography2' => 
      array (
        'font-family' => 'Source Sans Pro',
        'font-size' => '1.4em',
        'variant' => '300',
        'line-height' => '130%',
        'letter-spacing' => 'normal',
        'subsets' => 
        array (
        ),
        'color' => '#ffffff',
        'text-transform' => 'none',
      ),
      'header_content_subtitle_spacing2' => 
      array (
        'top' => '0',
        'bottom' => '0',
      ),
      'header_content_text_vertical_align' => 'v-align-top',
      'header_content_vertical_align' => 'v-align-top',
      'header_content_video_img_shadow' => '1',
      'header_content_inner_subtitle_typography' => 
      array (
        'font-family' => 'Source Sans Pro',
        'font-size' => '1.4em',
        'font-weight' => '300',
        'line-height' => '130%',
        'letter-spacing' => 'normal',
        'subsets' => 
        array (
        ),
        'color' => '#ffffff',
        'text-transform' => 'none',
      ),
      'one_page_express_header_content_image_rounded' => '0',
      'one_page_express_header_video_popup_image_disabled' => false,
      'header_nav_menu_color' => '#FFFFFF',
      'header_nav_sticky_title_typography' => '#000000',
      'header_text_logo_color' => '#ffffff',
      'one_page_express_header_btn_1_class' => 'button hp-header-primary-button blue big',
      'one_page_express_header_btn_2_class' => 'button hp-header-secondary-button green big',
      'content_media_vertical_align' => 'center',
      'one_page_express_header_color_video_popup_button' => '#FFFFFF',
      'one_page_express_header_color_video_popup_button_hover' => '#03a9f4',
      'one_page_express_header_background_type' => 'gradient',
      'one_page_express_front_page_header_overlap' => '0',
      'one_page_express_header_image' => '[tag_theme_uri]/assets/images/home_page_header.jpg',
    ),
  ),
  'preset-4' => 
  array (
    'index' => 3,
    'id' => 'header_preset_3',
    'thumb' => '//onepageexpress.com/default-assets/previews/headers/preset-4.png',
    'preview' => '//onepageexpress.com/default-assets/previews/headers/preset-4.png',
    'description' => 'image background with text content (default)',
    'settings' => 
    array (
      'one_page_express_headernav_header_1' => '',
      'one_page_express_header_nav_border' => '0',
      'one_page_express_header_nav_boxed' => '0',
      'one_page_express_header_nav_sticked' => '1',
      'one_page_express_header_nav_transparent' => '1',
      'one_page_express_header_header_1' => '',
      'one_page_express_full_height' => '0',
      'one_page_express_header_gradient' => 'plum_plate',
      'one_page_express_header_slideshow' => 
      array (
        0 => 
        array (
          'url' => '[tag_theme_uri]/assets/images/home_page_header.jpg',
        ),
        1 => 
        array (
          'url' => '[tag_theme_uri]/assets/images/jeremy-bishop-14593.jpg',
        ),
      ),
      'one_page_express_header_slideshow_duration' => 5000,
      'one_page_express_header_slideshow_speed' => 1000,
      'one_page_express_header_parallax' => '1',
      'one_page_express_header_overlay_header' => '',
      'one_page_express_header_show_overlay' => '1',
      'one_page_express_header_overlay_color' => '#000',
      'one_page_express_header_overlay_opacity' => 0.4,
      'one_page_express_header_separator_header' => '',
      'one_page_express_header_show_separator' => '1',
      'one_page_express_header_separator' => 'triangle-asymmetrical-negative',
      'one_page_express_header_separator_height' => 90,
      'one_page_express_inner_headernav_header_1' => '',
      'one_page_express_inner_header_nav_border' => '0',
      'one_page_express_inner_header_nav_boxed' => '0',
      'one_page_express_inner_header_nav_sticked' => '1',
      'one_page_express_inner_header_nav_transparent' => '1',
      'one_page_express_inner_header_header_1' => '',
      'one_page_express_inner_header_gradient' => 'plum_plate',
      'one_page_express_inner_header_slideshow' => 
      array (
        0 => 
        array (
          'url' => 'http://10.44.205.110/wp-content/themes/one-page-express/assets/images/home_page_header.jpg',
        ),
        1 => 
        array (
          'url' => 'http://10.44.205.110/wp-content/themes/one-page-express/assets/images/jeremy-bishop-14593.jpg',
        ),
      ),
      'one_page_express_inner_header_slideshow_duration' => 5000,
      'one_page_express_inner_header_slideshow_speed' => 1000,
      'one_page_express_inner_header_parallax' => '1',
      'one_page_express_inner_header_overlay_header' => '',
      'one_page_express_inner_header_show_overlay' => '1',
      'one_page_express_inner_header_overlay_color' => '#000',
      'one_page_express_inner_header_overlay_opacity' => 0.4,
      'one_page_express_inner_header_separator_header' => '',
      'one_page_express_inner_header_show_separator' => '1',
      'one_page_express_inner_header_separator' => 'triangle-asymmetrical-negative',
      'one_page_express_inner_header_separator_height' => 90,
      'one_page_express_inner_header_text_align' => 'center',
      'one_page_express_inner_header_show_subtitle' => '1',
      'one_page_express_inner_header_spacing' => 
      array (
        'top' => '8%',
        'bottom' => '8%',
      ),
      'one_page_express_header_content_separator' => '',
      'one_page_express_blog_header_overlap' => '1',
      'one_page_express_blog_header_margin' => '200px',
      'one_page_express_header_content_partial' => 'content-on-center',
      'one_page_express_header_text_align' => 'right',
      'one_page_express_header_spacing' => 
      array (
        'top' => '12%',
        'bottom' => '12%',
      ),
      'one_page_express_header_column_width' => 50,
      'one_page_express_header_content_width' => '80',
      'one_page_express_header_content_image' => '[tag_theme_uri]/screenshot.jpg',
      'one_page_express_header_content_title_separator' => '',
      'one_page_express_header_show_title' => '1',
      'one_page_express_header_content_subtitle_separator' => '',
      'one_page_express_header_show_subtitle' => '1',
      'one_page_express_header_content_primary_button_separator' => '',
      'one_page_express_header_show_btn_1' => '1',
      'one_page_express_header_btn_1_label' => '',
      'one_page_express_header_btn_1_url' => '#',
      'one_page_express_header_content_secondary_button_separator' => '',
      'one_page_express_header_show_btn_2' => '1',
      'one_page_express_header_btn_2_label' => '',
      'one_page_express_header_btn_2_url' => '#',
      'ope_header_content_layout' => 'content-on-right',
      'one_page_express_header_video_popup_image' => '[tag_theme_uri]/assets/images/Mock-up.jpg',
      'header_text_logo_title_typography_sep' => '',
      'header_text_logo_title_typography' => 
      array (
        'font-family' => 'inherit',
        'font-size' => '2.6em',
        'font-weight' => '600',
        'line-height' => '100%',
        'letter-spacing' => '0px',
        'subsets' => 
        array (
        ),
        'text-transform' => 'none',
        'color' => '#FFFFFF',
      ),
      'header_text_logo_sticky_typography' => '#000000',
      'header_nav_title_typography_sep' => '',
      'header_nav_title_typography' => 
      array (
        'font-family' => 'inherit',
        'font-size' => '1em',
        'font-weight' => '400',
        'line-height' => '115%',
        'letter-spacing' => '3px',
        'subsets' => 
        array (
        ),
        'text-transform' => 'uppercase',
        'color' => '#EDEDED',
      ),
      'header_nav_sitcky_title_typography' => '#000000',
      'header_content_inner_nav_sep' => '',
      'inner_header_nav_logo_color' => '#ffffff',
      'inner_header_nav_menu_color' => '#FFFFFF',
      'ope_header_nav_bar_color' => '#FFFFFF',
      'ope_inner_header_nav_bar_color' => '#FFFFFF',
      'header_content_title_typography' => 
      array (
        'font-family' => 'Source Sans Pro',
        'font-size' => '3.3em',
        'font-weight' => '600',
        'line-height' => '115%',
        'letter-spacing' => 'normal',
        'subsets' => 
        array (
        ),
        'color' => '#ffffff',
        'text-transform' => 'uppercase',
      ),
      'header_content_title_spacing' => 
      array (
        'top' => '0',
        'bottom' => '25px',
      ),
      'header_content_subtitle_typography' => 
      array (
        'font-family' => 'Source Sans Pro',
        'font-size' => '1.4em',
        'font-weight' => '300',
        'line-height' => '130%',
        'letter-spacing' => 'normal',
        'subsets' => 
        array (
        ),
        'color' => '#ffffff',
        'text-transform' => 'none',
      ),
      'header_content_subtitle_spacing' => 
      array (
        'top' => '0',
        'bottom' => '0',
      ),
      'header_content_inner_typography_sep' => '',
      'header_content_inner_title_typography' => 
      array (
        'font-family' => 'Source Sans Pro',
        'font-size' => '3.3em',
        'font-weight' => '600',
        'line-height' => '115%',
        'letter-spacing' => 'normal',
        'subsets' => 
        array (
        ),
        'color' => '#ffffff',
        'text-transform' => 'uppercase',
      ),
      'ope_header_content_media' => 'image',
      'ope_pro_header_content_video' => 'https://www.youtube.com/watch?v=3iXYciBTQ0c',
      'header_content_media_spacing' => 
      array (
        'top' => '0',
        'bottom' => '0',
      ),
      'one_page_express_header_show_bottom_arrow_separator' => '',
      'one_page_express_header_show_bottom_arrow' => '0',
      'one_page_express_header_bottom_arrow' => 'fa-chevron-down',
      'one_page_express_header_size_bottom_arrow' => '20',
      'one_page_express_header_offset_bottom_arrow' => '20',
      'one_page_express_header_color_bottom_arrow' => '#000000',
      'one_page_express_header_background_bottom_arrow' => '#ffffff',
      'one_page_express_header_text_morph_separator' => '',
      'one_page_express_header_show_text_morph_animation' => '1',
      'one_page_express_header_text_morph_speed' => 200,
      'one_page_express_header_text_morph_alternatives' => '',
      'one_page_express_header_bounce_bottom_arrow' => '1',
      'ope_pro_header_buttons_type' => 'normal',
      'one_page_express_header_content_subtitle_separator2' => '',
      'one_page_express_header_show_subtitle2' => '0',
      'header_content_subtitle_typography2' => 
      array (
        'font-family' => 'Source Sans Pro',
        'font-size' => '1.4em',
        'variant' => '300',
        'line-height' => '130%',
        'letter-spacing' => 'normal',
        'subsets' => 
        array (
        ),
        'color' => '#ffffff',
        'text-transform' => 'none',
      ),
      'header_content_subtitle_spacing2' => 
      array (
        'top' => '0',
        'bottom' => '0',
      ),
      'header_content_text_vertical_align' => 'v-align-top',
      'header_content_vertical_align' => 'v-align-top',
      'header_content_video_img_shadow' => '1',
      'header_content_inner_subtitle_typography' => 
      array (
        'font-family' => 'Source Sans Pro',
        'font-size' => '1.4em',
        'font-weight' => '300',
        'line-height' => '130%',
        'letter-spacing' => 'normal',
        'subsets' => 
        array (
        ),
        'color' => '#ffffff',
        'text-transform' => 'none',
      ),
      'one_page_express_header_content_image_rounded' => '0',
      'one_page_express_header_video_popup_image_disabled' => false,
      'header_nav_menu_color' => '#FFFFFF',
      'header_nav_sticky_title_typography' => '#000000',
      'header_text_logo_color' => '#ffffff',
      'one_page_express_header_btn_1_class' => 'button hp-header-primary-button blue big',
      'one_page_express_header_btn_2_class' => 'button hp-header-secondary-button green big',
      'content_media_vertical_align' => 'center',
      'one_page_express_header_color_video_popup_button' => '#FFFFFF',
      'one_page_express_header_color_video_popup_button_hover' => '#03a9f4',
      'one_page_express_front_page_header_margin' => '200px',
      'one_page_express_header_background_type' => 'image',
      'one_page_express_header_image' => '[tag_theme_uri]/assets/images/home_page_header.jpg',
    ),
  ),
);
