<table class="action" align="center" width="100%" cellpadding="0" cellspacing="0">
	<tr>
		<td align="center">
			<table width="100%" border="0" cellpadding="0" cellspacing="0">
				<tr>
					<td align="center">
						<table border="0" cellpadding="0" cellspacing="0">
							<tr>
								<td>
									<a href="<?php echo esc_url( isset( $url ) ? $url : '#' ); ?>" class="button button-<?php echo esc_attr( isset( $color ) ? $color : 'blue' ); ?>" target="_blank"><?php echo $slot; ?></a>
								</td>
							</tr>
						</table>
					</td>
				</tr>
			</table>
		</td>
	</tr>
</table>
