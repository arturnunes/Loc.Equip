<?php
/**
 * Room Type Loop End
 *
 * @author 		Awethemes
 * @package 	AweBooking/Templates
 * @version     3.0.0
 */
?>
</ul>
