<?php
/**
 * Room Type Loop Start
 *
 * This template can be overridden by copying it to yourtheme/awebooking/loop/loop-start.php.
 *
 * @author 		Awethemes
 * @package 	AweBooking/Templates
 * @version     3.0.0
 */
?>
<ul class="room_types">
