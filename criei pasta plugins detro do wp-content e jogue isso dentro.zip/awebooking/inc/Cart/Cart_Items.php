<?php
namespace AweBooking\Cart;

use AweBooking\Support\Collection;

class Cart_Items extends Collection {

}
