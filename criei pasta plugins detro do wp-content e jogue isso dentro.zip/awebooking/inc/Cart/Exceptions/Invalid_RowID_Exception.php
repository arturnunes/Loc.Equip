<?php
namespace AweBooking\Cart\Exceptions;

class Invalid_RowID_Exception extends \InvalidArgumentException {}
