<?php
namespace AweBooking\Http\Exceptions;

class Validation_Failed_Exception extends \RuntimeException {}
