<?php
namespace AweBooking\Admin\Forms\Exceptions;

class NonceMismatchException extends \Exception {}
