<?php
namespace AweBooking\Model;

class Commission {

}
