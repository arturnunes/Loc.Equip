<?php
namespace AweBooking\Calendar\Event\Exceptions;

class Invalid_State_Exception extends \InvalidArgumentException {}
