<?php
namespace AweBooking\Calendar\Provider\Exceptions;

class Untrusted_Resource_Exception extends \RuntimeException {}
