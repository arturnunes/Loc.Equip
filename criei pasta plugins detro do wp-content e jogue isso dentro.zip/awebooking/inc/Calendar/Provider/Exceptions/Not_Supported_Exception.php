<?php
namespace AweBooking\Calendar\Provider\Exceptions;

class Not_Supported_Exception extends \RuntimeException {}
