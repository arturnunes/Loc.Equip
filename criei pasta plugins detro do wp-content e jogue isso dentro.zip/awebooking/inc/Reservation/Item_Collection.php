<?php
namespace AweBooking\Reservation;

use AweBooking\Support\Collection;

class Item_Collection extends Collection {
}
