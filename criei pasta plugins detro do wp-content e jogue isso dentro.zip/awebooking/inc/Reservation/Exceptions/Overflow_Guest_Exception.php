<?php
namespace AweBooking\Reservation\Exceptions;

class Overflow_Guest_Exception extends \OverflowException {}
