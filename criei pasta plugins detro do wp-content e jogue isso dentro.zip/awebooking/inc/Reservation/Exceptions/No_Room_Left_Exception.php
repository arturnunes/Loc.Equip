<?php
namespace AweBooking\Reservation\Exceptions;

class No_Room_Left_Exception extends \OutOfRangeException {}
