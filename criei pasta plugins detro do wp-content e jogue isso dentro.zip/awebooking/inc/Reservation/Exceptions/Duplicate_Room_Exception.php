<?php
namespace AweBooking\Reservation\Exceptions;

class Duplicate_Room_Exception extends \LogicException {}
