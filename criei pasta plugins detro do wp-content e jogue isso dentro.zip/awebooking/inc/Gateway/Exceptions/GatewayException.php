<?php
namespace AweBooking\Gateway\Exceptions;

class GatewayException extends RuntimeException {}
