<?php
namespace AweBooking\Gateway;

class Response {
}
